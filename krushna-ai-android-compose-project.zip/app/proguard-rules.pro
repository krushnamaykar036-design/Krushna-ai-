# Proguard rules for Gemini AI & OkHttp
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class com.assistant.ai.data.model.** { *; }
