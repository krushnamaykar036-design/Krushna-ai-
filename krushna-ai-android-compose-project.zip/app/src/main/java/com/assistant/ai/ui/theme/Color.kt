package com.assistant.ai.ui.theme

import androidx.compose.ui.graphics.Color

// Modern Dark Theme Palette (AMOLED friendly, high contrast)
val DarkBackground = Color(0xFF090A0F)
val DarkSurface = Color(0xFF13151D)
val DarkSurfaceVariant = Color(0xFF1D212F)
val DarkSurfaceBorder = Color(0xFF2B3145)

val PrimaryBlue = Color(0xFF6366F1) // Indigo 500
val PrimaryBlueVariant = Color(0xFF4F46E5)
val AccentCyan = Color(0xFF06B6D4) // Cyan 500
val AccentEmerald = Color(0xFF10B981)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

val UserBubbleBg = Color(0xFF312E81) // Deep Indigo
val AssistantBubbleBg = Color(0xFF181B26)
val AssistantBorder = Color(0xFF262C3E)

val MicPulseActive = Color(0xFFEF4444) // Red indicator when listening
val MicIdle = Color(0xFF6366F1)
