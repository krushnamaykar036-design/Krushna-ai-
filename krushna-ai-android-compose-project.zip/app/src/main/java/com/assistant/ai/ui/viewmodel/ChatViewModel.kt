package com.assistant.ai.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.assistant.ai.data.GeminiService
import com.assistant.ai.data.model.ChatMessage
import com.assistant.ai.data.model.MessageSender
import com.assistant.ai.data.model.SupportedLanguage
import com.assistant.ai.voice.VoiceManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val inputText: String = "",
    val selectedLanguage: SupportedLanguage = SupportedLanguage.ENGLISH,
    val isLoading: Boolean = false,
    val isListening: Boolean = false,
    val isSpeaking: Boolean = false,
    val isVoiceAutoReply: Boolean = true,
    val isVoiceMuted: Boolean = false,
    val hasAudioPermission: Boolean = false,
    val errorMessage: String? = null
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val geminiService = GeminiService()
    private val voiceManager = VoiceManager(application)

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    init {
        // Observe voice manager states
        viewModelScope.launch {
            voiceManager.isListening.collect { listening ->
                _uiState.update { it.copy(isListening = listening) }
            }
        }
        viewModelScope.launch {
            voiceManager.isSpeaking.collect { speaking ->
                _uiState.update { it.copy(isSpeaking = speaking) }
            }
        }

        voiceManager.onSpeechResult = { recognizedText ->
            _uiState.update { it.copy(inputText = recognizedText) }
            sendMessage(recognizedText)
        }

        voiceManager.onSpeechError = { errorMsg ->
            _uiState.update { it.copy(errorMessage = errorMsg, isListening = false) }
        }

        // Welcome message based on language
        addInitialGreeting()
    }

    private fun addInitialGreeting() {
        val greeting = when (_uiState.value.selectedLanguage) {
            SupportedLanguage.MARATHI -> "नमस्कार! मी कृष्णा AI (Krushna AI), तुमचा सहाय्यक आहे. मी मराठी, हिंदी आणि इंग्रजीमध्ये मदत करू शकतो. विचारा!"
            SupportedLanguage.HINDI -> "नमस्ते! मैं कृष्णा AI (Krushna AI), आपका सहायक हूँ। मैं मराठी, हिंदी और अंग्रेज़ी में आपकी सहायता कर सकता हूँ। पूछिए!"
            SupportedLanguage.ENGLISH -> "Hello! I am Krushna AI, your Android Assistant. I can assist you in Marathi, Hindi, and English. How can I help you today?"
        }

        _uiState.update {
            it.copy(
                messages = listOf(
                    ChatMessage(
                        text = greeting,
                        sender = MessageSender.ASSISTANT,
                        language = it.selectedLanguage
                    )
                )
            )
        }
    }

    fun onInputTextChanged(newText: String) {
        _uiState.update { it.copy(inputText = newText) }
    }

    fun setLanguage(language: SupportedLanguage) {
        if (_uiState.value.selectedLanguage == language) return
        voiceManager.stopSpeaking()
        _uiState.update { it.copy(selectedLanguage = language) }
    }

    fun toggleVoiceAutoReply() {
        val newAutoReply = !_uiState.value.isVoiceAutoReply
        if (!newAutoReply) {
            voiceManager.stopSpeaking()
        }
        _uiState.update { it.copy(isVoiceAutoReply = newAutoReply, isVoiceMuted = !newAutoReply) }
    }

    fun toggleVoiceMute() {
        toggleVoiceAutoReply()
    }

    fun onAudioPermissionGranted() {
        _uiState.update { it.copy(hasAudioPermission = true) }
    }

    fun onAudioPermissionDenied() {
        _uiState.update { it.copy(hasAudioPermission = false, errorMessage = "Microphone permission is required for voice input.") }
    }

    fun toggleMicListening() {
        if (!_uiState.value.hasAudioPermission) {
            _uiState.update { it.copy(errorMessage = "Microphone permission is needed.") }
            return
        }

        if (_uiState.value.isListening) {
            voiceManager.stopListening()
        } else {
            voiceManager.startListening(_uiState.value.selectedLanguage)
        }
    }

    fun sendMessage(textOverride: String? = null) {
        val textToSend = (textOverride ?: _uiState.value.inputText).trim()
        if (textToSend.isBlank() || _uiState.value.isLoading) return

        voiceManager.stopSpeaking()

        val userMessage = ChatMessage(
            text = textToSend,
            sender = MessageSender.USER,
            language = _uiState.value.selectedLanguage
        )

        _uiState.update {
            it.copy(
                messages = it.messages + userMessage,
                inputText = "",
                isLoading = true,
                errorMessage = null
            )
        }

        viewModelScope.launch {
            val result = geminiService.sendMessage(
                prompt = textToSend,
                language = _uiState.value.selectedLanguage,
                history = _uiState.value.messages
            )

            result.onSuccess { aiReply ->
                val assistantMessage = ChatMessage(
                    text = aiReply,
                    sender = MessageSender.ASSISTANT,
                    language = _uiState.value.selectedLanguage
                )

                _uiState.update {
                    it.copy(
                        messages = it.messages + assistantMessage,
                        isLoading = false
                    )
                }

                // Automatically speak response aloud using Android Text-To-Speech if Voice is ON
                if (_uiState.value.isVoiceAutoReply) {
                    voiceManager.speak(aiReply, _uiState.value.selectedLanguage)
                }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = error.localizedMessage ?: "Failed to get response from Gemini AI"
                    )
                }
            }
        }
    }

    fun speakMessage(message: ChatMessage) {
        if (message.sender == MessageSender.ASSISTANT) {
            voiceManager.speak(message.text, message.language)
        }
    }

    fun stopSpeaking() {
        voiceManager.stopSpeaking()
    }

    fun clearChat() {
        voiceManager.stopSpeaking()
        voiceManager.stopListening()
        _uiState.update {
            it.copy(
                messages = emptyList(),
                inputText = "",
                errorMessage = null
            )
        }
        addInitialGreeting()
    }

    fun dismissError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    fun cleanup() {
        voiceManager.destroy()
    }

    override fun onCleared() {
        super.onCleared()
        cleanup()
    }
}
