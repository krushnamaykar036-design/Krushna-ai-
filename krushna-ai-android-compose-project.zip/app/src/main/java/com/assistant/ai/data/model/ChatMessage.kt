package com.assistant.ai.data.model

import java.util.UUID

enum class MessageSender {
    USER,
    ASSISTANT
}

enum class SupportedLanguage(val code: String, val displayName: String, val nativeName: String) {
    MARATHI("mr", "Marathi", "मराठी"),
    HINDI("hi", "Hindi", "हिंदी"),
    ENGLISH("en", "English", "English")
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val sender: MessageSender,
    val timestamp: Long = System.currentTimeMillis(),
    val language: SupportedLanguage = SupportedLanguage.ENGLISH,
    val isSpeaking: Boolean = false,
    val isError: Boolean = false
)
