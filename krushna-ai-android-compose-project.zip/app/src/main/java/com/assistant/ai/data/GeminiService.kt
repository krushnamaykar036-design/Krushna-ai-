package com.assistant.ai.data

import com.assistant.ai.BuildConfig
import com.assistant.ai.data.model.ChatMessage
import com.assistant.ai.data.model.MessageSender
import com.assistant.ai.data.model.SupportedLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    // Model: gemini-3.8-flash
    private val endpointUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent"

    suspend fun sendMessage(
        prompt: String,
        language: SupportedLanguage,
        history: List<ChatMessage>,
        customApiKey: String? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val apiKey = customApiKey?.takeIf { it.isNotBlank() }
                ?: BuildConfig.GEMINI_API_KEY.takeIf { it.isNotBlank() }
                ?: return@withContext Result.failure(
                    IllegalStateException("GEMINI_API_KEY is not configured. Please provide an API key in the app or build config.")
                )

            val langInstruction = when (language) {
                SupportedLanguage.MARATHI -> "User selected MARATHI (मराठी). You MUST respond in fluent, grammatically correct Marathi (Devanagari script). Keep sentences crisp for voice read-out on Android phone."
                SupportedLanguage.HINDI -> "User selected HINDI (हिंदी). You MUST respond in fluent, grammatically correct Hindi (Devanagari script). Keep sentences crisp for voice read-out on Android phone."
                SupportedLanguage.ENGLISH -> "User selected ENGLISH. Respond in crisp, friendly English suitable for mobile screen reading and voice synthesis."
            }

            val systemInstructionText = """
                You are Krushna AI (कृष्णा AI), a native Android AI Voice & Chat Assistant built with Kotlin and Jetpack Compose.
                $langInstruction
                Keep replies natural, concise, polite, and directly helpful on an Android phone.
                Avoid unnecessary markdown symbols or complex tables so the text sounds great when read aloud via Android Text-To-Speech.
            """.trimIndent()

            val contentsArray = JSONArray()

            // Include last 6 turns for context
            val recentHistory = history.takeLast(6)
            for (msg in recentHistory) {
                val role = if (msg.sender == MessageSender.USER) "user" else "model"
                val partObj = JSONObject().put("text", msg.text)
                val turnObj = JSONObject()
                    .put("role", role)
                    .put("parts", JSONArray().put(partObj))
                contentsArray.put(turnObj)
            }

            // Current message
            contentsArray.put(
                JSONObject()
                    .put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            )

            val requestJson = JSONObject().apply {
                put("contents", contentsArray)
                put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemInstructionText))))
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.7)
                    put("maxOutputTokens", 800)
                })
            }

            val requestBody = requestJson.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder()
                .url("$endpointUrl?key=$apiKey")
                .header("User-Agent", "aistudio-build")
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string()

            if (!response.isSuccessful || responseBody == null) {
                return@withContext Result.failure(
                    Exception("Gemini API error (${response.code}): ${responseBody ?: "Unknown error"}")
                )
            }

            val root = JSONObject(responseBody)
            val candidates = root.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.getJSONObject("content")
                val parts = content.getJSONArray("parts")
                val text = parts.getJSONObject(0).getString("text")
                Result.success(text)
            } else {
                Result.failure(Exception("No response generated by Gemini model."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
