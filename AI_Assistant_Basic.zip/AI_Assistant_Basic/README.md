# AI Assistant Basic

Android Studio project for a simple AI Assistant interface.

Features:
- Text chat interface
- Android speech recognition button
- Basic offline replies
- No API key required for this basic version

Open the folder in Android Studio and build the app.
