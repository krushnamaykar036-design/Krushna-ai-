package com.example.aiassistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    TextView chat; EditText input; final int VOICE = 10;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        chat=findViewById(R.id.chat); input=findViewById(R.id.input);
        findViewById(R.id.send).setOnClickListener(v -> send());
        findViewById(R.id.mic).setOnClickListener(v -> voice());
    }

    void send() {
        String q=input.getText().toString().trim();
        if(q.isEmpty()) return;
        chat.append("You: "+q+"\nAssistant: "+reply(q)+"\n\n");
        input.setText("");
    }

    String reply(String q) {
        String x=q.toLowerCase(Locale.ROOT);
        if(x.contains("hello") || x.contains("hi") || q.contains("नमस्कार"))
            return "नमस्कार! काय मदत करू?";
        if(x.contains("time") || q.contains("वेळ"))
            return "तुझ्या फोनवरील वर्तमान वेळ पाहण्यासाठी घड्याळ उघड.";
        if(x.contains("who are you") || q.contains("तू कोण"))
            return "मी तुझा Basic AI Assistant आहे.";
        return "हे Basic version आहे. तुझा प्रश्न मिळाला: "+q;
    }

    void voice() {
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 20);
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        startActivityForResult(i, VOICE);
    }

    @Override protected void onActivityResult(int r,int c,Intent d) {
        super.onActivityResult(r,c,d);
        if(r==VOICE && c==RESULT_OK && d!=null) {
            ArrayList<String> a=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if(a!=null && !a.isEmpty()) { input.setText(a.get(0)); send(); }
        }
    }
}
