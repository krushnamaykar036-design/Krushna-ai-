# Krishna AI Assistant Advanced

Android app with:
- Text chat
- Marathi/Hindi/English voice input
- Text-to-speech replies
- App-opening commands (YouTube, WhatsApp, Chrome, Settings)
- Dialer opening for a spoken/typed phone number (user confirms the call)
- Web search command
- Optional online AI using an OpenAI-compatible chat-completions endpoint

## Build
Open the project in Android Studio and build the APK.

## Online AI setup
Open the app's ⚙ button and enter:
1. AI API URL (an OpenAI-compatible `/chat/completions` endpoint)
2. Model name
3. API key

The key is entered at runtime instead of being hard-coded into the APK.
