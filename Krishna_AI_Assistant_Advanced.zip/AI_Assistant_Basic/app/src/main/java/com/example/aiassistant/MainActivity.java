package com.example.aiassistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.Toast;
import android.app.AlertDialog;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private TextView chat;
    private EditText input;
    private ScrollView scroll;
    private TextToSpeech tts;
    private String lastAnswer = "";
    private static final int VOICE = 10;
    private static final int MIC_PERMISSION = 20;
    private static final String PREFS = "ai_settings";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        chat = findViewById(R.id.chat); input = findViewById(R.id.input); scroll = findViewById(R.id.scroll);
        tts = new TextToSpeech(this, status -> { if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("mr", "IN")); });
        findViewById(R.id.send).setOnClickListener(v -> send());
        findViewById(R.id.mic).setOnClickListener(v -> voice());
        findViewById(R.id.speak).setOnClickListener(v -> speak(lastAnswer));
        findViewById(R.id.settings).setOnClickListener(v -> showSettings());
        input.setOnEditorActionListener((v, actionId, event) -> { if (actionId == EditorInfo.IME_ACTION_SEND) { send(); return true; } return false; });
    }

    private void send() {
        String q = input.getText().toString().trim();
        if (q.isEmpty()) return;
        append("You: " + q + "\n");
        input.setText("");
        if (handleCommand(q)) return;
        String key = getPrefs().getString("key", "").trim();
        if (key.isEmpty()) {
            answer(localReply(q));
            return;
        }
        append("Assistant: विचार करत आहे...\n\n");
        new Thread(() -> {
            String result = callAi(q);
            runOnUiThread(() -> {
                removeThinking();
                answer(result);
            });
        }).start();
    }

    private boolean handleCommand(String q) {
        String x = q.toLowerCase(Locale.ROOT);
        String digits = q.replaceAll("[^0-9+]", "");
        if ((x.contains("call") || q.contains("कॉल") || q.contains("फोन")) && digits.replace("+", "").length() >= 8) {
            try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + digits))); }
            catch (Exception e) { Toast.makeText(this, "Dialer उघडता आला नाही", Toast.LENGTH_SHORT).show(); }
            answer("Dialer उघडला आहे. नंबर तपासून Call दाब.");
            return true;
        }
        if (x.contains("youtube") || q.contains("यूट्यूब")) { openPackage("com.google.android.youtube", "YouTube"); return true; }
        if (x.contains("whatsapp") || q.contains("व्हॉट्सअॅप")) { openPackage("com.whatsapp", "WhatsApp"); return true; }
        if (x.contains("chrome") || q.contains("क्रोम")) { openPackage("com.android.chrome", "Chrome"); return true; }
        if (x.contains("settings") || q.contains("सेटिंग")) { try { startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); } catch (Exception ignored) {} return true; }
        if (x.contains("search") || q.contains("सर्च") || q.contains("शोध")) {
            String query = q.replaceAll("(?i)(search|सर्च|शोध)", "").trim();
            if (query.isEmpty()) query = q;
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))));
            answer("Google search उघडला."); return true;
        }
        return false;
    }

    private void openPackage(String pkg, String name) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i != null) startActivity(i); else Toast.makeText(this, name + " install नाही", Toast.LENGTH_SHORT).show();
            answer(name + " उघडण्याचा प्रयत्न केला.");
        } catch (Exception e) { Toast.makeText(this, name + " उघडता आले नाही", Toast.LENGTH_SHORT).show(); }
    }

    private String localReply(String q) {
        String x = q.toLowerCase(Locale.ROOT);
        if (x.contains("hello") || x.contains("hi") || q.contains("नमस्कार")) return "नमस्कार! काय मदत करू?";
        if (x.contains("who are you") || q.contains("तू कोण")) return "मी Krishna AI Assistant आहे. Voice, commands आणि optional AI chat देतो.";
        if (x.contains("time") || q.contains("वेळ")) return "तुझ्या फोनचे घड्याळ उघडून वर्तमान वेळ पाहू शकतोस.";
        return "AI API key सेट केलेली नाही. ⚙ Settings मध्ये API URL, model आणि key भरल्यावर online AI replies सुरू होतील.";
    }

    private String callAi(String q) {
        try {
            SharedPreferences p = getPrefs();
            String endpoint = p.getString("url", "").trim();
            String model = p.getString("model", "").trim();
            String key = p.getString("key", "").trim();
            if (endpoint.isEmpty() || model.isEmpty()) return "AI settings अपूर्ण आहेत. ⚙ मध्ये URL आणि model भरा.";
            HttpURLConnection c = (HttpURLConnection) new URL(endpoint).openConnection();
            c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(30000);
            c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("Authorization", "Bearer " + key);
            JSONObject body = new JSONObject(); body.put("model", model);
            JSONArray messages = new JSONArray();
            JSONObject system = new JSONObject(); system.put("role", "system"); system.put("content", "You are Krishna AI Assistant. Reply clearly and briefly. Understand Marathi, Hindi and English."); messages.put(system);
            JSONObject user = new JSONObject(); user.put("role", "user"); user.put("content", q); messages.put(user);
            body.put("messages", messages);
            OutputStream os = c.getOutputStream(); os.write(body.toString().getBytes(StandardCharsets.UTF_8)); os.close();
            BufferedReader br = new BufferedReader(new InputStreamReader(c.getResponseCode() >= 400 ? c.getErrorStream() : c.getInputStream()));
            StringBuilder sb = new StringBuilder(); String line; while ((line = br.readLine()) != null) sb.append(line); br.close();
            if (c.getResponseCode() >= 400) return "AI server error: " + sb;
            JSONObject out = new JSONObject(sb.toString());
            JSONArray choices = out.optJSONArray("choices");
            if (choices != null && choices.length() > 0) {
                JSONObject msg = choices.getJSONObject(0).optJSONObject("message");
                if (msg != null) return msg.optString("content", "उत्तर मिळाले नाही.").trim();
            }
            return "AI कडून अपेक्षित उत्तर format मिळाला नाही.";
        } catch (Exception e) { return "AI connection error. Internet आणि Settings तपास."; }
    }

    private void answer(String s) { lastAnswer = s; append("Assistant: " + s + "\n\n"); }
    private void append(String s) { chat.append(s); scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN)); }
    private void removeThinking() {
        String t = chat.getText().toString();
        String marker = "Assistant: विचार करत आहे...\n\n";
        if (t.endsWith(marker)) chat.setText(t.substring(0, t.length() - marker.length()));
    }

    private void speak(String s) { if (s == null || s.isEmpty()) return; tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "answer"); }

    private void voice() {
        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION); return;
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "mr-IN");
        try { startActivityForResult(i, VOICE); } catch (Exception e) { Toast.makeText(this, "Voice recognition उपलब्ध नाही", Toast.LENGTH_SHORT).show(); }
    }

    @Override protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);
        if (r == VOICE && c == RESULT_OK && d != null) {
            ArrayList<String> a = d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (a != null && !a.isEmpty()) { input.setText(a.get(0)); send(); }
        }
    }

    private SharedPreferences getPrefs() { return getSharedPreferences(PREFS, MODE_PRIVATE); }

    private void showSettings() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(30, 10, 30, 0);
        EditText url = field("AI API URL (OpenAI-compatible chat endpoint)", getPrefs().getString("url", ""));
        EditText model = field("Model name", getPrefs().getString("model", ""));
        EditText key = field("API key", getPrefs().getString("key", "")); key.setInputType(0x00000081);
        box.addView(url); box.addView(model); box.addView(key);
        new AlertDialog.Builder(this).setTitle("⚙ AI Settings").setView(box)
            .setMessage("API key APK मध्ये hard-code केलेली नाही; ती या फोनवर locally save होते.")
            .setPositiveButton("Save", (d, w) -> { getPrefs().edit().putString("url", url.getText().toString().trim()).putString("model", model.getText().toString().trim()).putString("key", key.getText().toString().trim()).apply(); Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show(); })
            .setNegativeButton("Cancel", null).show();
    }

    private EditText field(String hint, String value) { EditText e = new EditText(this); e.setHint(hint); e.setText(value); e.setTextColor(0xFFFFFFFF); e.setHintTextColor(0xFFAAAAAA); e.setSingleLine(true); e.setPadding(0, 8, 0, 8); return e; }

    @Override protected void onDestroy() { if (tts != null) { tts.stop(); tts.shutdown(); } super.onDestroy(); }
}
