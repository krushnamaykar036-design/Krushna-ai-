package com.krushna.assistant;

import android.Manifest;import android.app.Activity;import android.content.*;import android.content.pm.PackageManager;import android.net.Uri;import android.os.Bundle;import android.speech.RecognizerIntent;import android.speech.tts.TextToSpeech;import android.view.View;import android.widget.*;import java.text.SimpleDateFormat;import java.util.*;

public class MainActivity extends Activity {
  TextView output; TextToSpeech tts; final int MIC=10;
  @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main); output=findViewById(R.id.output);
    tts=new TextToSpeech(this, s -> { if(s==TextToSpeech.SUCCESS) tts.setLanguage(new Locale("mr","IN")); });
    findViewById(R.id.micButton).setOnClickListener(v->listen());
    if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC);
  }
  void listen(){try{Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"mr-IN");i.putExtra(RecognizerIntent.EXTRA_PROMPT,"बोला…");startActivityForResult(i,11);}catch(Exception e){say("Voice recognition उपलब्ध नाही.");}}
  @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==11&&c==RESULT_OK&&d!=null){ArrayList<String>x=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(x!=null&&!x.isEmpty()) handle(x.get(0));}}
  void handle(String q){String s=q.toLowerCase(Locale.ROOT);output.setText("तू: "+q);if(s.contains("youtube")){open("https://www.youtube.com");say("YouTube उघडतो.");}else if(s.contains("instagram")){open("https://www.instagram.com");say("Instagram उघडतो.");}else if(s.contains("whatsapp")){open("https://wa.me/");say("WhatsApp उघडतो.");}else if(s.contains("settings")||s.contains("सेटिंग")){startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));say("Settings उघडतो.");}else if(s.contains("वेळ")||s.contains("time")){String t=new SimpleDateFormat("hh:mm a",Locale.getDefault()).format(new Date());say("आत्ता वेळ "+t+" आहे.");}else if(s.contains("फोन")||s.contains("call")||s.contains("कॉल")){startActivity(new Intent(Intent.ACTION_DIAL));say("Phone dialer उघडला.");}else{say("मी ऐकलं: "+q+". हा Basic version आहे; पुढच्या version मध्ये अधिक AI commands जोडता येतील.");}}
  void open(String u){try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));}catch(Exception ignored){}}
  void say(String t){output.append("\n\nAI: "+t);if(tts!=null)tts.speak(t,TextToSpeech.QUEUE_FLUSH,null,"ai");}
  @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
