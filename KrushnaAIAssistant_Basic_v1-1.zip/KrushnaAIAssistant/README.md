# Krushna AI Assistant — Basic Free v1

Android voice assistant starter project.

## Included
- Marathi voice input (Android Speech Recognizer)
- Text-to-speech reply
- YouTube / Instagram / WhatsApp opening
- Android Settings opening
- Phone dialer opening
- Simple time command
- Dark assistant UI
- GitHub Actions one-click cloud build workflow

## One-click cloud build
1. Create a GitHub repository and upload this folder.
2. Open **Actions → Build APK → Run workflow**.
3. Download the generated `Krushna-AI-Assistant-debug` artifact.

This v1 is intentionally basic and free. A real LLM/AI backend can be added later without putting a private API key inside the APK.
